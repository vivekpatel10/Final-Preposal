//
//  Game Elements.swift
//  Escape Covid
//
//  Created by Vivek Patel on 12/7/20.
//

import SpriteKit

struct CollisionBitMask {
    static let birdCategory:UInt32 = 0x1; &lt;&lt; 0
    static let pillarCategory:UInt32 = 0x1; &lt;&lt; 1
    static let flowerCategory:UInt32 = 0x1; &lt;&lt; 2
    static let groundCategory:UInt32 = 0x1; &lt;&lt; 3
}

extension GameScene {
}


