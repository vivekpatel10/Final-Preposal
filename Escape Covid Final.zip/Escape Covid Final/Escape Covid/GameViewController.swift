//
//  GameViewController.swift
//  Escape Covid
//
//
// created by Vivek Patel 11/21/2020
//

import UIKit
import SpriteKit

class GameViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
            let scene = GameScene(size: view.bounds.size)
            let sKView = view as! SKView
            sKView.showsFPS = false
            sKView.showsNodeCount = false
            sKView.ignoresSiblingOrder = false
            scene.scaleMode = .resizeFill
            sKView.presentScene(scene)
    
    }
    
    override var shouldAutorotate: Bool {
        return false
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
}
